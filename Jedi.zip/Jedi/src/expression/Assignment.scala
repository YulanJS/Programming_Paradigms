package expression
import value._
import context._
case class Assignment(private val vbl: Identifier, private val update: Expression) extends SpecialForm{   
   def execute(env: Environment): Value = 
   {
     env.put(vbl, update.execute(env))
     Notification.DONE
   }   
}