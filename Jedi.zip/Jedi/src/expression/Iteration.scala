package expression
import value._
import context._
case class Iteration(private val condition: Expression, val body: Expression) extends SpecialForm{
  def execute(env: Environment): Value = 
  {
    condition.execute(env).asInstanceOf[Boole] match
    {
      case Boole(true) => body.execute(env) 
      case Boole(false) => 
      case _ => new JediException("iteration: condition must be executed to boolean variable")
    }    
    Notification.DONE
  }
}