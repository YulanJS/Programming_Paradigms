package value

import collection.mutable._
import context._

//???
//shorter way of toString?
class Store(private var elems: ArrayBuffer[Value] = ArrayBuffer[Value]()) extends Value {
  // adds e to the end of store
  def add(e: Value) {elems += e}
  
  // inserts e at position pos in this
  def put(e: Value, pos: Integer) {
    if(pos.value < 0 || pos.value > elems.length - 1) throw new IndexOutOfBoundsException(pos.toString)
    elems.insert(pos.value, e)
  }
  
  // removes element at position pos from this
  def rem(pos: Integer) {
    if(pos.value < 0 || pos.value > elems.length - 1) throw new IndexOutOfBoundsException(pos.toString)
    elems.remove(pos.value)
  }
  
  // returns element at position pos in this
  def get(pos: Integer): Value = elems(pos.value)
  
  // returns true ie this contains e
  def contains(e: Value): Boole = Boole(elems.contains(e))
  
  // returns the size of this
  def size: Integer = Integer(elems.length)
  
  // returns "{e0 e1 e2 ...}"
  override def toString = 
  {
    var result = "{"
    for(eachElem <- elems)
    {
      result += eachElem.toString
    }
    result += "}"
    result
  }
  
   
  // returns store containing the elements of this transformed by trans
  def map(trans: Closure): Store = 
  {
    //one to one mapping:   
    var callEnv = new Environment()
    //ArrayBuffer has a map(lambda ) function
    new Store(elems.map((e: Value) => trans.apply(List(e), callEnv)))
  }
  
  // returns store containing the elements of this that passed test
  def filter(test: Closure): Store = 
  {
    var callEnv = new Environment()
    //ArrayBuffer has a filter(lambda) function    
    //??? What if it is not Boolean type       
    new Store(elems.filter((e: Value) => test.apply(List(e), callEnv).asInstanceOf[Boolean]))
  }
  
}