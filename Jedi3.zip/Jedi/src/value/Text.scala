package value
import expression._
class Text(val body: Expression) extends Value{
  //passByText
  
}