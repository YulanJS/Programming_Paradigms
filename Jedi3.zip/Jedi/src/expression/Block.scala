package expression
import context._
case class Block(val exps: List[Expression]) extends SpecialForm {
  def execute(env: Environment) = 
  {
    //(1) tempEnv = new Env(env)
    val tempEnv = new Environment(env)
    //(2) execute exps relative to tempEnv: 
    //one by one, but the return value is the last one
    for(exp <- exps)
    {
      exp.execute(tempEnv)
    }
    //(3) return value of last one
    exps(exps.length - 1).execute(tempEnv)
  }
  //temp env will be deleted after...
}